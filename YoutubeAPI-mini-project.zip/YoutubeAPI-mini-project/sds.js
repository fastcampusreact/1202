import React from 'react';
import './App.css';
import axios from 'axios';
import Nav from './Components/Nav/Nav';
import SearchBar from './Components/SearchBar'
import VideoList from './Components/VideoList/VideoList';
import { debounce } from 'lodash';
import InfiniteScroll from 'react-infinite-scroller';
import uuid from 'uuid';
import {spinner} from './Components/images';
import VideoDetail from './Components/VideoPlayer/VideoDetail';



class App extends React.Component {
  constructor(props) {
    super(props)
    Object.getOwnPropertyNames(App.prototype).forEach(
      key => this[key] = this[key].bind(this)) /**자동으로 바인딩하기위한 함수없었으면 this.getYoutubeData=this.getYoutubeData.bind(this)해야함 */

    this.state = {
      videos: [],
      selectedVideos: null,
      query: '',
      nextPageToken: null
    } /**초기화 비어있는 객체로 초기화 초기화하지않으면 setState하지못함 */

    this.defaultState=this.state;
  }
  //UPSERT:UPDATE+INSERT
  //getYoutubeData() undefined였을때 여행이 된다.
  async getYoutubeData(query) {
    if(!query)return
    if(this.state.query !== query){
      this.setState(this.defaultState);
    }

    const { nextPageToken } = this.state;
 
    const params = {
      key: "AIzaSyBSLIjdTd0U9Vqmr_0aJMhuJCbKYyjnq40",
      q: query,
      part: "snippet",
      maxResults: 10,
      pageToken: nextPageToken,
    }
      const { data } = await axios.get(`https://www.googleapis.com/youtube/v3/search`, { params });

      this.setState({ 
      videos:[...this.state.videos,...data.items],
      query,
      nextPageToken: data.nextPageToken
      });
      /**state에 data가 추가 됨; */
  }
    async componentWillMount(){ /**렌더되기 이전에 실행이 된다.*/
      this.getYoutubeData('여행');
    }
    setInput(input){//setInput(input)의input은 매개변수로 받고 이는 setState에 의해서 input에 저장 한다.
      this.setState({ input });//setState에 의해서 input의 변경의 요청한다.
    }
  render() {
    const {input,selectedVideos}=this.state;
    return (
      <div className="App">
        <Nav>
          <SearchBar input={input} setInput={this.setInput} onSearchVideos={debounce(this.getYoutubeData,500)}/>
        </Nav>
        
        <InfiniteScroll
        loadMore={()=>this.getYoutubeData(this.state.query)}
        hasMore={!!this.state.nextPageToken && !this.state.selectedVideos}
        /**단축 평가(&&) 왼쪽이 true 이면 오른쪽을 반환 ,false일 때 반대*/
        /**hasMore은 무조건 true/false리턴 */
        loader={
          <div key={uuid.v4()} className="loader">{/**key을 사용하는 이유는 어떤항목을 변경,추가 또는 삭제할지 식별하는 것을 돕는다.  */}
            <img src={spinner} alt="loading" />
          </div>
        }>
          {
            selectedVideos
            ?<VideoDetail videos={this.state.selectedVideos}/>
            :<VideoList
            {...this.state}
            onVideoSelect={selectedVideos=>this.setState({selectedVideos})}
            />
          }
        </InfiniteScroll>
  
      </div>
        );
      }
    }
export default App;