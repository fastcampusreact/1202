module.exports = {
  spinner: require('./spinner.gif')
}