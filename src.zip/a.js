const getPrice = percent => price => (1 - percent) * price;

const tenpercentOff = getPrice(0.1);
const twentycentOff = getPrice(0.2);

const price = tenpercentOff(10000);
const price = twentycentOff(10000);