import React from 'react';
import Hello from './Hello';
import './App.css'

class App extends React.Component {
  constructor(props) {
    super(props); // react.component는 this를 사용하기 위함, 상위 클래스 호출
    this.state = { //역할, 상태 변화를 일으키는 모든 변수를 정의, 객체 이긴 하지만
      counter: 0,
      className: "App-header-2"
    }
  }

  render() { //화면에 출력한다. render함수는 1초마다 계속 실행된다.

    const name = 'react';
    const style = {
      backgroundColor: 'black',
      color: 'aqua',
      fontSize: 24,
      padding: '1rem'
    }
    return (
      <>
        <Hello />
        <div>{name}</div>
        <div style={style}>{name}</div>
        <div className="gray-box"></div>
      </>
    );
  }
}

export default App;
