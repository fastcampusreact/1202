const axios = require('axios');

const search = async (query, maxPage) => {
  const result = []

  const { nextPageToken, items } = data;

  for (const i = 0; i < 10; i++) {
    const params = nextPageToken => ({
      key: 'AIzaSyC1Y_pxHo33uSJV-HmXtP_jBhKNhbwnxug',
      q: query,
      part: 'snippet',
      maxResults: 10,
      pageToken: nextPageToken
    })

    const { data } = await axios.get(`https://www.googleapis.com/youtube/v3/search`, { params })

  }

  result.push(items)
}



results.push(data.items)