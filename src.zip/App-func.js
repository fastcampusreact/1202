import React from 'react';
import Outer from './outer';
import Inner from './inner';
import Count from './count';

function App() {
  return (
   <Outer>
     <Inner name="김지성" color="red" />
     <Inner name="김진" color="blue" />
     <Inner />
     <Count />
   </Outer>
  )
}

export default App;