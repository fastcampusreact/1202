import React from 'react';

const Inner = ({ color, name }) => {
  return (
    <>
      <h1 style={{color}}>{name}</h1>
      <div>안녕하세요</div>
    </>
  )
}

Inner.defaultProps = {
  name : "없을때 default",
  color : "green"
}

export default Inner;