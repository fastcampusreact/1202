import React from 'react'

let dataYoutube = [];

const ajaxGetYoutube = async () => {
  dataYoutube = await fetch('https://www.googleapis.com/youtube/v3/search?key=AIzaSyCT5YNj0WpEUrt_4K8b3GZ6NoBZTOImXMA&q=travel&part=snippet&pageToken=CAUQAA').then(res => res.json())
  console.log(dataYoutube)
}
ajaxGetYoutube();
const Youtubes = () => {
  return (
    dataYoutube
  )
}

export default Youtubes;