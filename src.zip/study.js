const after1 = new Promise(resolve => setTimeout(() => resolve(1), 1000))
const after2 = new Promise(resolve => setTimeout(() => resolve(2), 2000))
const after3 = new Promise(resolve => setTimeout(() => resolve(3), 3000))

const main = async () => {
  const tasks = [after3, after2, after1]

  // 잘된예제 //비동기 순서 예제는 for of를 사용해야 한다.
  for (const task of tasks) {
    console.log(await task)
  }

  // 잘못된 예제
  // tasks.forEach(async task => console.log(await (task)))
  // for each와 for of의 차이는 for of 는 순서를 기다리지만, for Each는 순서를 기다리지 않는다.

  // fetch를 사용할때는 3가지의 이슈가 있다. axios를 사용하면 자동적으로 다 사용할 수 있다.
}

main()
