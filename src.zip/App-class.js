import React from 'react';
import Outer from './outer';
import Inner from './inner';
import Calc from './count100';


class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0,
      className: 'App-header-1'
    }
  }

  componentDidMount() {
    setInterval(() => this.setState({
      counter : this.state.counter + 1
    }), 1000)
  }

  Calc (val) {
    this.setState({counter : this.state.counter + val})
    console.log(this)
  }

  ajaxGetYoutube() {
    const test = fetch('https://www.googleapis.com/youtube/v3/search?key=AIzaSyCT5YNj0WpEUrt_4K8b3GZ6NoBZTOImXMA&q=travel&part=snippet&pageToken=CAUQAA').then(res => res.json());
    console.log(test);
  }

  render() {
    console.log(this);
    return (
      <div className="App">
        <Outer>
        <h1>{this.state.counter}</h1>
        <button onClick={this.Calc}>+100</button>

        <button onClick={() => { this.Calc(-100); }}>-100</button>
        <Inner name="hello" color="red" />
        </Outer>
      </div>
    )
  }

}

export default App;