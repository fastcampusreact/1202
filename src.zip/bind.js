const obj = {
  name: 'minwoo',
  email: 'a@.a'
}
console.log(Object.keys(obj));