import React, { Component } from 'react';
import Axios from 'axios';
import uuid from 'uuid';
import { debounce } from 'lodash';
import InfiniteScroll from 'react-infinite-scroller';
import spinner from "./components/images/spinner.gif";

import Header from './components/Header/Header';
import Nav from './components/Nav/Nav';
import SearchBar from './components/SearchBar/SearchBar';
import VideoList from './components/VideoList/VideoList';
import VideoListItem from './components/VideoList/VideoListItem';
import VideoPlayer from './components/VideoPlayer/VideoPlayer';


class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
      videos: [],
      selectedVideo: null,
      nextPageToken: null,
      query: '',
    }
    this.defaultState = this.state;
    this.ajaxGetYoutubeData = this.ajaxGetYoutubeData.bind(this)
  }

  async ajaxGetYoutubeData(query) {
    if (!query) return;
    if (this.state.query !== query) this.setState(this.defaultState)

    const { nextPageToken } = this.state;

    const params = {
      key: process.env.REACT_APP_YOUTUBE_API_KEY,
      q: query,
      part: `snippet`,
      maxResults: 8,
      pageToken: nextPageToken
    }

    const { data } = await Axios.get(`https://www.googleapis.com/youtube/v3/search`, { params })

    this.setState({
      videos: data.items,
      query,
      nextPageToken: data.nextPageToken,
    })
  }

  componentWillMount() {
    this.ajaxGetYoutubeData(`travel`);
  }

  render () {
    const { videos, selectedVideo } = this.state;

    return (
      <div className="App">
        <Header>
          <Nav>
            <SearchBar onChangeVideo={debounce(this.ajaxGetYoutubeData, 1000)} />
          </Nav>
        </Header>
        <div className="content">
          {
          selectedVideo
          ? <VideoPlayer onChangeVideo={selectedVideo} />
          : <InfiniteScroll
              loadMore={() => this.ajaxGetYoutubeData(this.state.query)}
              hasMore={!!this.state.nextPageToken}
              loader={
                <div className="loader" key={0}>Loading ...</div>
              }
            >
              <VideoList>
                {videos.map( video => <VideoListItem key={uuid.v4()} {...video} onChangeVideo={selectedVideo => this.setState({ selectedVideo })} />)}
              </VideoList>
            </InfiniteScroll>
          }
        </div>
      </div>
    )
  }
}

export default App;
