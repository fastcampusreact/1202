import React, { useState } from 'react';

const Count = (props) => {
  const [number, setNumber] = useState(0)
  console.log(setNumber)
  const onIncrease = () => {
    setNumber(prevNumber => prevNumber + 1);
  }
  const onDecrease = () => {
    setNumber(prevNumber => prevNumber - 1);
  }

  return (
    <>
      <h2>{ number }</h2>
      <button onClick={onIncrease} className='btn-plus'>+</button>
      <button onClick={onDecrease} className='btn-minus'>-</button>
    </>
  )

}

export default Count;