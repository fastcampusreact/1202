import React from 'react';

const Outer = ({ children }) => {
  const style = {
    backgroundColor: 'pink',
    border: '2px solid red',
    padding: 100
  }
return <div style={ style }>{children}</div>
}

export default Outer;