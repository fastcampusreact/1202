import React from 'react';
import styled from 'styled-components';

const Header = props => {
  const Header = styled.header`
    background-color: #fff;
    border-bottom: 1px solid #d1d1d1;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
  `
  return (
    <Header>
      {props.children}
    </Header>
  )
}
export default Header;