import React from 'react';
import styled from 'styled-components';

const VideoPlayer = props => {
  const VideoPlayer = styled.div`
    padding: 50px 100px;
  `

    const videoId= props.onChangeVideo.id.videoId,
          videoTitle = props.onChangeVideo.snippet.channelTitle,
          videoDescription = props.onChangeVideo.snippet.description,
          url = `https://www.youtube.com/embed/${videoId}`;


  return (
    <VideoPlayer>
      {console.log(props.onChangeVideo)}
      <iframe width="704" height="396" src={ url } title={ videoTitle }></iframe>
      <h3>{videoTitle}</h3>
      <p>{videoDescription}</p>
    </VideoPlayer>
  )
}

export default VideoPlayer;