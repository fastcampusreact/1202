import React from 'react';
import styled from 'styled-components';

const VideoListItem = props => {
  const ListItem = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    .img-content {
      flex-basis: 20%;
    }
    .text-content {
      flex-basis: 80%;
    }
    img {
      width: 100%;
      height: auto;
    }
  `;

  const videoData = {
    title: props.snippet.title,
    description: props.snippet.description,
    img: props.snippet.thumbnails.medium.url,
  }

  return (
    <li onClick={() =>  props.onChangeVideo(props)}>
      <ListItem>
        <div className="img-content">
          <img src={videoData.img} alt={videoData.title} />
        </div>
        <div className="text-content">
          <h3>{videoData.title}</h3>
          <p>{videoData.description}</p>
        </div>
      </ListItem>
    </li>
  )

}

export default VideoListItem;