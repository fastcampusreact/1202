import React from 'react';

const VideoList = props => {
  return (
    <ul className="video-list-wraper">
      {props.children}
    </ul>
  )
}

export default VideoList;