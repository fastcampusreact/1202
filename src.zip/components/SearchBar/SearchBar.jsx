import React from 'react';
import styled from 'styled-components';


const SearchBar = props => {
  const Input = styled.input`
    width: 400px;
    height: 50px;
    border: 1px solid #d1d1d1;
  `

  const Button = styled.button`
    height: 50px;
    width: 70px;
  `

  const handleEnter = search => e => {
    if (e.keyCode !== 13) return;
    search(e.target.value)
  }

  let input;
  return (
    <div className="search">
      <Input
        ref={ref => (input = ref)}
        type="search"
        onKeyUp={handleEnter(props.onChangeVideo)}
        onChange={(e) => props.onChangeVideo(e.target.value)}
      />
      <Button type="button" onClick={(e) => props.onChangeVideo(input.value)}>찾기</Button>
    </div>
  )
}

export default SearchBar;