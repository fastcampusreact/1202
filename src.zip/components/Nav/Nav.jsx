import React from 'react';
import imgLogo from './images/logo.jpg'
import styled from 'styled-components';


const Nav = props => {
  const Logo = styled.h1`
    width: 200px;
    img {
      width: 100%;
      height: auto;
    }
  `

  return (
    <>
      <Logo className="logo">
        <a href="#">
          <img src={ imgLogo } alt="로고"/>
        </a>
      </Logo>
      <div className="search-wrapper">
        {props.children}
      </div>
    </>
  )
}

export default Nav;