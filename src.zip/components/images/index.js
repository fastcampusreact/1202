module.export = {
  snpinner : require('./spinner.gif')
}