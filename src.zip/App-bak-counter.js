import React from 'react';
import logo from './logo.svg';
import './App.css';

// Stateless component : 상태 변화가 없다.
const Img = props => <Img src={logo} className="App-logo" alt={props.alt} />

const Header = props => <header>{props.children}
      <Img src={logo} className={props.className} />
</header>

class App extends React.Component {
  constructor(props) {
    super(props); // react.component는 this를 사용하기 위함, 상위 클래스 호출
    this.state = { // 역할, 상태 변화를 일으키는 모든 변수를 정의, 객체 이긴 하지만
      counter: 0,
      className: "App-header-2"
    }

    // this.add = this.add.bind(this);
    // this.minus = this.minus.bind(this);
    Object.keys(this).forEach(key => {
      if (typeof this[key] === 'function') {
        this[key] = this[key].bind(this);
      }
    });
  }

  componentDidMount() { //상위에있는 메소드를 오버라이드해서 사용
    setInterval(() => this.setState({
      counter: this.state.counter + 1 // ++는 그자체를 업데이트하기 때문에 안된다
    }) ,1000);
    // this.setState(state => ({
    //   counter: state.counter + 1
    // }));
    // setState는 비동기함수 콜백함수로 내보낼 수 있다.
    console.log(this.setState())
    // setInterval(() => this.setState({
    //   counter: this.state.counter + 1 // ++는 그자체를 업데이트하기 때문에 안된다
    // }), () => {
    //   console.log()
    // }, 1000);
    // console.log()
  }

  calc (val) {
    this.setState({ counter : this.state.counter + val});
  }

  render() { //화면에 출력한다. render함수는 1초마다 계속 실행된다.
    return (
      <div className="App">
        <button onClick={() => this.calc(100)}>+</button>{this.state.counter}<button onClick={() => this.calc(-100)}>-</button>
        {/* <Header className={this.state.className}>
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </Header> */}
      </div>
    );
  }
}

export default App;