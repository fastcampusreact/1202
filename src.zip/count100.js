import React from 'react';
import { setState } from 'expect/build/jestMatchersObject';

const Calc = () => {
  const countState = () => setState({count : this.state.counter + 100})

  return (
    <>
      <button onClick={countState}>+100</button>
      <button onClick={countState}>-100</button>
    </>
  )
}

export default Calc;